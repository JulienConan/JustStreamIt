from django.apps import AppConfig


class TitlesConfig(AppConfig):
    name = 'api.v1.titles'
