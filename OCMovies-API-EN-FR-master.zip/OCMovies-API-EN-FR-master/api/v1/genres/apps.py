from django.apps import AppConfig


class GenresConfig(AppConfig):
    name = 'api.v1.genres'
